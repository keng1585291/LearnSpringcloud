# springcloud-book

#### gitee下载地址：https://gitee.com/forezp/springcloud-book

### 第二版源码地址

https://github.com/forezp/springcloud-book-greenwich

##### 获取SpringCloud 、Spring Boot视频：https://www.fangzhipeng.com/share/2017/10/01/resource-sharing.html

<div>
    <p align="center">
        <img src="https://www.fangzhipeng.com/img/avatar.jpg" width="258" height="258"/>
        <br>
        扫码关注公众号有惊喜
    </p>
    <p align="center" style="margin-top: 15px; font-size: 11px;color: #cc0000;">
        <strong>（转载本站文章请注明作者和出处 <a href="https://www.fangzhipeng.com">方志朋的博客</a>）</strong>
    </p>
</div>


### 书籍购买地址


![1.jpg](https://upload-images.jianshu.io/upload_images/2279594-3d9ee1555f555040.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/300)

[点击购买书籍-京东](https://item.jd.com/12312724.html)

[点击购买书籍-当当](http://product.dangdang.com/25231114.html)

[点击购买书籍-亚马逊](https://www.amazon.cn/dp/B079J8SCGY/ref=sr_1_2?ie=UTF8&qid=1521344315&sr=8-2&keywords=spring+cloud)




### 怎么使用源码

打开开发工具IDEA，然后file-open具体的章节的源码，注意不是open 整个跟目录。例如：

￼![image.png](https://upload-images.jianshu.io/upload_images/2279594-5337ed9945c271fa.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/600)
